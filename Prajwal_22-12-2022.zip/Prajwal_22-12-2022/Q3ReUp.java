package Run;
import java.util.Scanner;
public class ReUpQ3
{
public static void main(String[] args) 
{
	
	System.out.println("enter the string :");
	Scanner s = new Scanner(System.in);
	String s1 = s.nextLine();
	String s2=s1.toUpperCase();
	StringBuilder s3 = new StringBuilder();
	s3.append(s2);
	s3.reverse();
	System.out.println("Reversed string with uppercase is: "+s3);
	}
}


