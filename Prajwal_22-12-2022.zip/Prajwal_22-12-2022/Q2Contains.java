package Run;
import java.util.Scanner;
public class Q2Contains
{
	public static void main(String[] args)
	{
        Scanner s = new Scanner(System.in);
		System.out.println("type the first string : ");
		String s1= s.next();
		System.out.println("type 2nd first string : ");
		String s2= s.next();
		if(s1.contains(s2))
		{
		System.out.println("words are there in other sting");
		}
		else
		{
		System.out.println("there is no content of 1st string");
		}
	}
}
