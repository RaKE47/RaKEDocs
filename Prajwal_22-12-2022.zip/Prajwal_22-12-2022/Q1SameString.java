package Run;
import java.util.*;

class Q1SameString 
{
public static void main(String[] args)
    {
	 Scanner s = new Scanner(System.in);
     String s1 = s.nextLine();
     System.out.println("enter 1st string :" + s1);
	 String s2 = s.nextLine();
     System.out.println("enter another string :"+ s2);
     
        if (s1.equals(s2) == true)
        {
            System.out.println("strings are same");
        }
        else 
        {
            System.out.println("strings are not same");
        }
    }
}